#pragma once

#include <versatile/type_traits.hpp>
#include <versatile/in_place.hpp>
#include <versatile/recursive_wrapper.hpp>
#include <versatile/aggregate_wrapper.hpp>
#include <versatile/visit.hpp>
#include <versatile/versatile.hpp>
#include <versatile/variant.hpp>
#include <versatile/utility.hpp>
#include <versatile/compare.hpp>
#include <versatile/io.hpp>
